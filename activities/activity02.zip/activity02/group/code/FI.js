// const courseData = {
//   "courses": [
//     {
//       "course_id": "CS101",
//       "course_name": "Introduction to Computer Science",
//       "sessions": [
//         {
//           "session_id": "S1",
//           "period": "2025-09-01 to 2025-12-15"
//         },
//         {
//           "session_id": "S2",
//           "period": "2026-01-10 to 2026-04-25"
//         }
//       ],
//       "reports": [
//         {
//           "report_id": "R1",
//           "title": "Midterm Performance",
//           "submitted_on": "2025-10-20"
//         },
//         {
//           "report_id": "R2",
//           "title": "Final Project Evaluation",
//           "submitted_on": "2025-12-20"
//         }
//       ]
//     },
//     {
//       "course_id": "MATH201",
//       "course_name": "Calculus II",
//       "sessions": [
//         {
//           "session_id": "S1",
//           "period": "2025-09-05 to 2025-12-20"
//         }
//       ],
//       "reports": [
//         {
//           "report_id": "R1",
//           "title": "Quiz Summary",
//           "submitted_on": "2025-11-10"
//         }
//       ]
//     }
//   ]
// };

// const users = [
//   {
//     "username": "intern1",
//     "password": "12345"
//   },
//   {
//     "username": "intern2",
//     "password": "admin"
//   }
// ];



// const loginBtn = document.getElementById("loginBtn");
// const loginSection = document.getElementById("login-section");
// const dashboardSection = document.getElementById("dashboard-section");

// loginBtn.addEventListener("click", () => {
//   const username = document.getElementById("username").value.trim();
//   const password = document.getElementById("password").value.trim();

//   if (username && password) {
//     showAlert("Login Successful");
//     setTimeout(() => {
//       loginSection.style.display = "none";
//       dashboardSection.style.display = "block";
//     }, 1000);
//   } else {
//     showAlert("Enter username and password", true);
//   }
// });

// function showAlert(message, error = false) {
//   let alertBox = document.createElement("div");
//   alertBox.className = "alert";
//   alertBox.style.background = error ? "#d9534f" : "#00a86b";
//   alertBox.textContent = message;
//   document.body.appendChild(alertBox);
//   alertBox.style.display = "block";
//   setTimeout(() => alertBox.remove(), 2000);
// }

// function populateCourses() {
//   const courseList = document.querySelector("#courses ul");
//   courseList.innerHTML = ""; // Clear existing list

//   courseData.courses.forEach(course => {
//     const li = document.createElement("li");
//     li.textContent = `${course.course_name} (${course.course_id})`;
//     courseList.appendChild(li);
//   });
// }

// function populateReports() {
//   const reportList = document.querySelector("#reports ul");
//   reportList.innerHTML = ""; // Clear existing list

//   courseData.courses.forEach(course => {
//     course.reports.forEach(report => {
//       const li = document.createElement("li");
//       li.textContent = `${report.title} - Submitted on ${report.submitted_on}`;
//       reportList.appendChild(li);
//     });
//   });
// }

// const isValidUser = users.some(user => user.username === username && user.password === password);

// if (isValidUser) {
//   showAlert("Login Successful");
//   setTimeout(() => {
//     loginSection.style.display = "none";
//     dashboardSection.style.display = "block";

//     // You can also call data population functions here if needed
//     populateCourses();
//     populateReports();
//   }, 1000);
// } else {
//   showAlert("Invalid username or password", true);
// }



// // Navigation buttons
// const navButtons = document.querySelectorAll(".nav-btn");
// const sections = document.querySelectorAll(".content-section");

// navButtons.forEach(btn => {
//   btn.addEventListener("click", () => {
//     sections.forEach(sec => sec.classList.remove("active"));
//     const target = btn.getAttribute("data-section");
//     document.getElementById(target).classList.add("active");
//   });
// });


// updated version that fixes loading issues
const courseData = {
  "courses": [
    {
      "course_id": "CS101",
      "course_name": "Introduction to Computer Science",
      "sessions": [
        {
          "session_id": "S1",
          "period": "2025-09-01 to 2025-12-15"
        },
        {
          "session_id": "S2",
          "period": "2026-01-10 to 2026-04-25"
        }
      ],
      "reports": [
        {
          "report_id": "R1",
          "title": "Midterm Performance",
          "submitted_on": "2025-10-20"
        },
        {
          "report_id": "R2",
          "title": "Final Project Evaluation",
          "submitted_on": "2025-12-20"
        }
      ]
    },
    {
      "course_id": "MATH201",
      "course_name": "Calculus II",
      "sessions": [
        {
          "session_id": "S1",
          "period": "2025-09-05 to 2025-12-20"
        }
      ],
      "reports": [
        {
          "report_id": "R1",
          "title": "Quiz Summary",
          "submitted_on": "2025-11-10"
        }
      ]
    }
  ]
};

// Wait for DOM to be fully loaded before running any code
document.addEventListener('DOMContentLoaded', function() {
  
  // Check if we're on the login page or dashboard page
  const loginSection = document.getElementById("login-section");
  const dashboardSection = document.getElementById("dashboard-section");
  
  // If dashboard section exists and is visible, initialize dashboard functionality
  if (dashboardSection && dashboardSection.offsetParent !== null) {
    initializeDashboard();
  }
  
  // If login section exists, initialize login functionality
  if (loginSection) {
    initializeLogin();
  }
  
});

// Initialize Login Functionality
function initializeLogin() {
  const loginBtn = document.getElementById("loginBtn");
  
  if (!loginBtn) return; // Exit if login button doesn't exist
  
  // NOTE: Login validation is now handled by PHP
  // This JavaScript is kept for potential client-side enhancements
  loginBtn.addEventListener("click", () => {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    
    if (!username || !password) {
      showAlert("Please enter both username and password", true);
    }
  });
}

// Initialize Dashboard Functionality
function initializeDashboard() {
  // Navigation buttons
  const navButtons = document.querySelectorAll(".nav-btn");
  const sections = document.querySelectorAll(".content-section");
  
  // Make sure dashboard section is visible on load
  const dashboardContent = document.getElementById("dashboard");
  if (dashboardContent) {
    dashboardContent.classList.add("active");
  }
  
  // Add click handlers to navigation buttons
  navButtons.forEach(btn => {
    btn.addEventListener("click", function() {
      // Remove active class from all buttons
      navButtons.forEach(b => b.classList.remove("active"));
      
      // Add active class to clicked button
      this.classList.add("active");
      
      // Hide all sections
      sections.forEach(sec => sec.classList.remove("active"));
      
      // Show target section
      const target = this.getAttribute("data-section");
      const targetSection = document.getElementById(target);
      if (targetSection) {
        targetSection.classList.add("active");
      }
    });
  });
  
  // Populate dynamic data
  populateCourses();
  populateReports();
}

// Populate courses from courseData
function populateCourses() {
  const courseList = document.querySelector("#courses ul");
  if (!courseList) return; // Exit if element doesn't exist
  
  courseList.innerHTML = ""; // Clear existing list

  courseData.courses.forEach(course => {
    const li = document.createElement("li");
    li.textContent = `${course.course_name} (${course.course_id})`;
    
    // Add session info
    const sessionInfo = document.createElement("span");
    sessionInfo.style.fontSize = "0.9em";
    sessionInfo.style.color = "#666";
    sessionInfo.textContent = ` - ${course.sessions.length} session(s)`;
    li.appendChild(sessionInfo);
    
    courseList.appendChild(li);
  });
}

// Populate reports from courseData
function populateReports() {
  const reportList = document.querySelector("#reports ul");
  if (!reportList) return; // Exit if element doesn't exist
  
  reportList.innerHTML = ""; // Clear existing list

  courseData.courses.forEach(course => {
    course.reports.forEach(report => {
      const li = document.createElement("li");
      li.textContent = `${course.course_name}: ${report.title} - Submitted on ${report.submitted_on}`;
      reportList.appendChild(li);
    });
  });
}

// Show alert message
function showAlert(message, error = false) {
  let alertBox = document.createElement("div");
  alertBox.className = "alert";
  alertBox.style.position = "fixed";
  alertBox.style.top = "20px";
  alertBox.style.right = "20px";
  alertBox.style.padding = "15px 20px";
  alertBox.style.borderRadius = "5px";
  alertBox.style.color = "white";
  alertBox.style.fontWeight = "bold";
  alertBox.style.zIndex = "10000";
  alertBox.style.boxShadow = "0 4px 6px rgba(0,0,0,0.1)";
  alertBox.style.background = error ? "#d9534f" : "#00a86b";
  alertBox.textContent = message;
  
  document.body.appendChild(alertBox);
  alertBox.style.display = "block";
  
  setTimeout(() => alertBox.remove(), 3000);
}
