<?php
session_start();
require_once 'dbh_include.php';

header('Content-Type: application/json');

function sendResponse($success, $message)
{
    echo json_encode(["success" => $success, "message" => $message]);
    exit;
}

if (!isset($pdo) || $pdo === null) {
    sendResponse(false, "Database connection failed");
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    sendResponse(false, "Invalid request method");
}

$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";

if (empty($username) || empty($password)) {
    sendResponse(false, "Please fill in all fields");
}

// Check if user exists
try {
    $stmt = $pdo->prepare("SELECT username, password_hash FROM users WHERE username = ?");
    $stmt->execute([$username]);

    if ($stmt->rowCount() === 0) {
        sendResponse(false, "Incorrect username or password");
    }

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verify password
    if (!password_verify($password, $user["password_hash"])) {
        sendResponse(false, "Incorrect username or password");
    }

    // Set session variables
    //$_SESSION["student_id"] = $user["student_id"];
    $_SESSION["username"] = $username;

    sendResponse(true, "Login successful!");
} catch (PDOException $e) {
    error_log("Login error: " . $e->getMessage());
    sendResponse(false, "Unable to login. Try again later.");
}
