// const registerBtn = document.getElementById("registerBtn");

// function goToLogin() {
//     window.location.href = "LoginPage.html";
// }

// registerBtn.addEventListener("click", () => {
//   const username = document.getElementById("reg-username").value.trim();
//   const email = document.getElementById("reg-email").value.trim();
//   const password = document.getElementById("reg-password").value.trim();
//   const confirmPassword = document.getElementById("reg-confirm-password").value.trim();

//   // Validation
//   if (!username || !email || !password || !confirmPassword) {
//     showAlert("All fields are required", true);
//     return;
//   }

//   // Email validation
//   const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//   if (!emailPattern.test(email)) {
//     showAlert("Please enter a valid email", true);
//     return;
//   }

//   // Password length check
//   if (password.length < 5) {
//     showAlert("Password must be at least 5 characters", true);
//     return;
//   }

//   // Password match check
//   if (password !== confirmPassword) {
//     showAlert("Passwords do not match", true);
//     return;
//   }

//   // Load existing users from localStorage
//   let users = JSON.parse(localStorage.getItem("registeredUsers")) || [];

//   // Check if username already exists
//   const userExists = users.some(u => u.username === username);
//   if (userExists) {
//     showAlert("Username already exists", true);
//     return;
//   }

//   // Check if email already exists
//   const emailExists = users.some(u => u.email === email);
//   if (emailExists) {
//     swal
//     showAlert("Email already registered", true);
//     return;
//   }

//   // Add new user
//   const newUser = {
//     username: username,
//     email: email,
//     password: password
//   };

//   users.push(newUser);
//   localStorage.setItem("registeredUsers", JSON.stringify(users));

//   showAlert("Registration Successful! Redirecting to login...");
//   setTimeout(() => {
//     goToLogin();
//   }, 2000);
// });

// // initial Alert function without SweetAlert
// // function showAlert(message, error = false) {
// //   let alertBox = document.createElement("div");
// //   alertBox.className = "alert";
// //   alertBox.style.background = error ? "#d9534f" : "#10563cff";
// //   alertBox.textContent = message;
// //   document.body.appendChild(alertBox);
// //   alertBox.style.display = "block";
// //   setTimeout(() => alertBox.remove(), 2500);
// // }

// // Alert function using SweetAlert2
// function showAlert(message, error = false) {
//   Swal.fire({
//     title: error ? 'Error!' : 'Success!',
//     text: message,
//     icon: error ? 'error' : 'success',
//     confirmButtonColor: error ? '#d9534f' : '#00a86b',
//     confirmButtonText: 'OK',
//     timer: error ? undefined : 2000,
//     timerProgressBar: true
//   });
// }




// const registrationForm = document.getElementById("registrationForm");

// // client-side validation before PHP processes it
// registrationForm.addEventListener("submit", (e) => {
//   const username = document.getElementById("reg-username").value.trim();
//   const email = document.getElementById("reg-email").value.trim();
//   const password = document.getElementById("reg-password").value.trim();
//   const confirmPassword = document.getElementById("reg-confirm-password").value.trim();

//   // Quick validation before sending to server
//   if (!username || !email || !password || !confirmPassword) {
//     e.preventDefault(); // Stop form submission
//     showAlert("All fields are required", true);
//     return;
//   }

//   if (password.length < 5) {
//     e.preventDefault();
//     showAlert("Password must be at least 5 characters", true);
//     return;
//   }

//   if (password !== confirmPassword) {
//     e.preventDefault();
//     showAlert("Passwords do not match", true);
//     return;
//   }


// });

// function showAlert(message, error = false) {
//   Swal.fire({
//     title: error ? 'Error!' : 'Success!',
//     text: message,
//     icon: error ? 'error' : 'success',
//     confirmButtonColor: error ? '#d9534f' : '#00a86b',
//     confirmButtonText: 'OK'
//   });
// }




// Add console log to check if script is loading
console.log("RegistrationScript.js loaded");

const registrationForm = document.getElementById("registrationForm");

// Check if form element is found
if (!registrationForm) {
    console.error("Form with id 'registrationForm' not found!");
} else {
    console.log("Form found:", registrationForm);
}

function goToLogin() {
    window.location.href = "LoginPage.html";
}

// Handle form submission with AJAX
registrationForm.addEventListener("submit", async (e) => {
  console.log("Form submit event triggered"); // Debug log
  
  e.preventDefault(); // Prevent default form submission
  console.log("Default form submission prevented"); // Debug log

  const username = document.getElementById("reg-username").value.trim();
  const email = document.getElementById("reg-email").value.trim();
  const password = document.getElementById("reg-password").value.trim();
  const confirmPassword = document.getElementById("reg-confirm-password").value.trim();

  console.log("Form values:", { username, email, password: "***", confirmPassword: "***" });

  // Client-side validation
  if (!username || !email || !password || !confirmPassword) {
    showAlert("All fields are required", true);
    return;
  }

  // Email validation
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    showAlert("Please enter a valid email", true);
    return;
  }

  // Password length check
  if (password.length < 5) {
    showAlert("Password must be at least 5 characters", true);
    return;
  }

  // Password match check
  if (password !== confirmPassword) {
    showAlert("Passwords do not match", true);
    return;
  }

  console.log("All validations passed, sending to server..."); // Debug log

  // Prepare form data
  const formData = new FormData(registrationForm);

  try {
    // Show loading indicator
    Swal.fire({
      title: 'Processing...',
      text: 'Creating your account',
      allowOutsideClick: false,
      didOpen: () => {
        Swal.showLoading();
      }
    });

    console.log("Sending POST request to register_process.php"); // Debug log

    // Send data to server
    const response = await fetch('register_process.php', {
      method: 'POST',
      body: formData
    });

    console.log("Response received:", response); // Debug log

    const result = await response.json();
    console.log("Result:", result); // Debug log

    if (result.success) {
      showAlert(result.message);
      setTimeout(() => {
        goToLogin();
      }, 2000);
    } else {
      showAlert(result.message, true);
    }

  } catch (error) {
    console.error("Error occurred:", error); // Debug log
    showAlert("An error occurred. Please try again.", true);
  }
});

// Alert function using SweetAlert2
function showAlert(message, error = false) {
  console.log("Showing alert:", message, "Error:", error); // Debug log
  
  Swal.fire({
    title: error ? 'Error!' : 'Success!',
    text: message,
    icon: error ? 'error' : 'success',
    confirmButtonColor: error ? '#d9534f' : '#00a86b',
    confirmButtonText: 'OK',
    timer: error ? undefined : 2000,
    timerProgressBar: true
  });
}