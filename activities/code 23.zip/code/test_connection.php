<?php
// $dsn = "mysql:host=localhost;dbname=webtech_2025A_mariana_eib";
// $dbusername = "mariana.eib";
// $dbpassword = "Sankye05";


$dsn = "mysql:host=127.0.0.1;dbname=attendance";
$dbusername = "root";
$dbpassword = "";

echo "<h2>Testing Database Connection...</h2>";

try {
    $pdo = new PDO($dsn, $dbusername, $dbpassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color: green;'>✓ Connection successful!</p>";

    // Test if users table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() > 0) {
        echo "<p style='color: green;'>✓ 'users' table exists</p>";

        // Show table structure
        $stmt = $pdo->query("DESCRIBE users");
        echo "<h3>Table Structure:</h3>";
        echo "<table border='1'>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th></tr>";
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>{$row['Field']}</td>";
            echo "<td>{$row['Type']}</td>";
            echo "<td>{$row['Null']}</td>";
            echo "<td>{$row['Key']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color: red;'>✗ 'users' table does NOT exist</p>";
    }
} catch (PDOException $e) {
    echo "<p style='color: red;'>✗ Connection failed: " . $e->getMessage() . "</p>";
    echo "<h3>Common Fixes:</h3>";
    echo "<ul>";
    echo "<li>Check if database name is correct</li>";
    echo "<li>Check if username is correct</li>";
    echo "<li>Check if password is correct</li>";
    echo "<li>Check if MySQL server is running</li>";
    echo "<li>Check if user has permission to access this database</li>";
    echo "</ul>";
}
