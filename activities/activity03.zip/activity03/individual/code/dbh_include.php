<?php
// database connection using PDO

$dsn = "mysql:host=localhost;dbname=webtech_2025A_mariana_eib";
$dbusername = "mariana.eib";
$dbpassword = "Sankye05";

try {
    // Create a database object using the PDO class
    $pdo = new PDO($dsn, $dbusername, $dbpassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Connection successful - but don't echo anything!

} catch (PDOException $e) {

    error_log("Database connection failed: " . $e->getMessage());

    // Set $pdo to null so we I check it later
    $pdo = null;
}
