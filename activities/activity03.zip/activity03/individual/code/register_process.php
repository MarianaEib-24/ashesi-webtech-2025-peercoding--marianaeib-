<?php
session_start();

// Include database connection
require_once 'dbh_include.php';

// Function to send JSON response
function sendResponse($success, $message)
{
    header('Content-Type: application/json');
    echo json_encode([
        'success' => $success,
        'message' => $message
    ]);
    exit;
}

// Check if database connection failed
if (!isset($pdo) || $pdo === null) {
    sendResponse(false, 'Database connection failed');
}

// Check if form was submitted via POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse(false, 'Invalid request method');
}

// Get form data
$first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
$last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';

// Validate data
if (empty($first_name)) {
    sendResponse(false, 'First name is required');
}

if (empty($last_name)) {
    sendResponse(false, 'Last name is required');
}

if (empty($username)) {
    sendResponse(false, 'Username is required');
}

if (empty($email)) {
    sendResponse(false, 'Email is required');
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    sendResponse(false, 'Invalid email format');
}

if (empty($password)) {
    sendResponse(false, 'Password is required');
}

if (strlen($password) < 5) {
    sendResponse(false, 'Password must be at least 5 characters');
}

if ($password !== $confirm_password) {
    sendResponse(false, 'Passwords do not match');
}

try {
    // Check if username already exists
    $stmt = $pdo->prepare("SELECT student_id FROM users WHERE username = ?");
    $stmt->execute([$username]);

    if ($stmt->rowCount() > 0) {
        sendResponse(false, 'Username already exists');
    }

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT student_id FROM users WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() > 0) {
        sendResponse(false, 'Email already registered');
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert new user
    $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, email, username, password_hash) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$first_name, $last_name, $email, $username, $hashed_password]);

    sendResponse(true, 'Registration successful! Redirecting to login...');
} catch (PDOException $e) {
    // Log the error (don't show detailed error to user in production)
    error_log("Registration error: " . $e->getMessage());
    sendResponse(false, 'Registration failed. Please try again.');
}
