<?php
	print ("this is my first php page");
	$pageColor= "#CCC"; 
	$name = "mariana";
?>
<script>
	document.body.style.backgroundColor = "<?php print($pageColor);  ?> ";
</script>
<?php
	var_dump($_GET);
	
	var_dump($name);

$ListOfNames = [
	"fname" => "Mari",
	"fname2" => "EIb",
	"fname3" => "Solo"

];

header(header:"location:https://www.google.com/search?q=learn&rlz=1C1GCEA_enGH1092GH1095&oq=learn&gs_lcrp=EgZjaHJvbWUyEQgAEEUYORhGGPkBGLEDGIAEMg0IARAAGIMBGLEDGIAEMgoIAhAAGLEDGIAEMgcIAxAAGIAEMgcIBBAAGIAEMgcIBRAAGIAEMgcIBhAAGIAEMgcIBxAAGIAEMgcICBAAGIAEMgcICRAAGIAE0gEJMzIyMmowajE1qAIIsAIB8QWyE9Wzdy-zTA&sourceid=chrome&ie=UTF-8");

$conn = newsqli(hostname: $servername, username: $username, password : $password, database: $dbname);
$querry = "select * from y";

//1.Server request
$_GET["fname"]; // this means you used a Get request to get the data sent to the server

if ($_SERVER['REQUEST_METHOD'=='GET']){
	echo "I came through GET","</br>";
}	
?>