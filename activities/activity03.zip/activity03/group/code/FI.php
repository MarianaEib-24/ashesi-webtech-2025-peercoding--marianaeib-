<?php
session_start();

// Get current page information
$current_url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$url_parts = parse_url($current_url);
parse_str($url_parts['query'] ?? '', $query_params);
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
$host = $_SERVER['HTTP_HOST'];
$query_string = $_SERVER['QUERY_STRING'] ?? 'None';

// Sample data - in a real application, this would come from a database
$users = [
    'intern1' => 'password123',
    'admin' => 'admin123'
];

$courses = [
    'Introduction to Programming',
    'Data Structures and Algorithms',
    'Web Development Fundamentals',
    'Database Systems',
    'Software Engineering'
];

$lecturers = [
    'Dr. Kwame Mensah',
    'Prof. Ama Boateng',
    'Mr. Yaw Ofori',
    'Ms. Lydia Owusu',
    'Dr. Albert Tetteh'
];

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (isset($users[$username]) && $users[$username] === $password) {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['login_time'] = date('Y-m-d H:i:s');
        // Redirect to remove POST data
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $error_message = "Invalid username or password";
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Check if user is logged in
$is_logged_in = isset($_SESSION['logged_in']) && $_SESSION['logged_in'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Intern Dashboard</title>
    <link rel="stylesheet" href="FI.css">
</head>

<body>

    <!-- LOGIN SECTION -->
    <?php if (!$is_logged_in): ?>
        <section id="login-section" class="active">
            <div class="login-container">
                <h1>Faculty Intern Portal</h1>
                <p>Sign in to continue</p>

                <?php if (isset($error_message)): ?>
                    <div style="color: red; margin: 10px 0;">
                        <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" name="login">Login</button>
                </form>

                <p style="margin-top: 15px; font-size: 0.9em; color: #666;">
                    Demo credentials: intern1 / password123
                </p>
            </div>
        </section>
    <?php else: ?>

        <!-- DASHBOARD SECTION -->
        <section id="dashboard-section">
            <header>
                <h2>Faculty Intern Dashboard</h2>
                <nav>
                    <button class="nav-btn active" data-section="dashboard">Dashboard</button>
                    <button class="nav-btn" data-section="courses">Courses</button>
                    <button class="nav-btn" data-section="lecturers">Lecturers</button>
                    <button class="nav-btn" data-section="reports">Reports</button>
                    <button class="nav-btn" data-section="page-info">Page Info</button>
                    <a href="?logout=1" style="margin-left: auto; color: white; text-decoration: none; padding: 10px;">Logout</a>
                </nav>
            </header>

            <div id="content">
                <!-- Dashboard Overview -->
                <div id="dashboard" class="content-section active">
                    <div class="card wide">
                        <h3>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?></h3>
                        <p>View quick stats and manage your teaching sessions below.</p>
                        <p style="font-size: 0.9em; color: #666;">
                            Last login: <?php echo htmlspecialchars($_SESSION['login_time']); ?>
                        </p>
                    </div>

                    <div class="grid">
                        <div class="card">
                            <h4>Total Courses</h4>
                            <p><?php echo count($courses); ?> Active Courses</p>
                        </div>
                        <div class="card">
                            <h4>Upcoming Sessions</h4>
                            <p>3 Sessions this week</p>
                        </div>
                        <div class="card">
                            <h4>Reports Submitted</h4>
                            <p>8 of 10 Completed</p>
                        </div>
                        <div class="card">
                            <h4>System Updates</h4>
                            <p>New analytics module added</p>
                        </div>
                    </div>
                </div>

                <!-- Courses -->
                <div id="courses" class="content-section">
                    <div class="card wide">
                        <h3>My Courses</h3>
                        <ul>
                            <?php foreach ($courses as $course): ?>
                                <li><?php echo htmlspecialchars($course); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <!-- Lecturers -->
                <div id="lecturers" class="content-section">
                    <div class="card wide">
                        <h3>Lecturers</h3>
                        <ul>
                            <?php foreach ($lecturers as $index => $lecturer): ?>
                                <li><?php echo ($index + 1) . '. ' . htmlspecialchars($lecturer); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <!-- Reports -->
                <div id="reports" class="content-section">
                    <div class="card wide">
                        <h3>Reports</h3>
                        <p>View and manage session reports:</p>
                        <ul>
                            <li>Week 1 Attendance Report - Submitted</li>
                            <li>Week 2 Session Report - Submitted</li>
                            <li>Week 3 Feedback Report - Pending</li>
                        </ul>
                    </div>
                </div>

                <!-- Page Info Section (NEW) -->
                <div id="page-info" class="content-section">
                    <div class="card wide">
                        <h3>📄 Current Page Information</h3>

                        <div class="page-info-box">
                            <h4>Basic Information</h4>
                            <div class="info-grid">
                                <div class="info-label">Full URL:</div>
                                <div class="info-value"><?php echo htmlspecialchars($current_url); ?></div>

                                <div class="info-label">Protocol:</div>
                                <div class="info-value"><?php echo htmlspecialchars($protocol); ?></div>

                                <div class="info-label">Domain/Host:</div>
                                <div class="info-value"><?php echo htmlspecialchars($host); ?></div>

                                <div class="info-label">Path:</div>
                                <div class="info-value"><?php echo htmlspecialchars($url_parts['path'] ?? '/'); ?></div>

                                <div class="info-label">Query String:</div>
                                <div class="info-value"><?php echo htmlspecialchars($query_string); ?></div>

                                <div class="info-label">Request Method:</div>
                                <div class="info-value"><?php echo htmlspecialchars($_SERVER['REQUEST_METHOD']); ?></div>
                            </div>
                        </div>

                        <?php if (!empty($query_params)): ?>
                            <div class="page-info-box">
                                <h4>🔍 URL Parameters</h4>
                                <ul class="params-list">
                                    <?php foreach ($query_params as $key => $value): ?>
                                        <li>
                                            <span class="param-name"><?php echo htmlspecialchars($key); ?>:</span>
                                            <span class="param-value"><?php echo htmlspecialchars($value); ?></span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php else: ?>
                            <div class="page-info-box">
                                <p style="color: #6c757d; margin: 0;">No URL parameters present. Try adding some! Example: ?course=PHP&level=beginner</p>
                            </div>
                        <?php endif; ?>

                        <div class="page-info-box">
                            <h4>🌐 Server & Client Information</h4>
                            <div class="info-grid">
                                <div class="info-label">Server IP:</div>
                                <div class="info-value"><?php echo htmlspecialchars($_SERVER['SERVER_ADDR'] ?? 'N/A'); ?></div>

                                <div class="info-label">Client IP:</div>
                                <div class="info-value"><?php echo htmlspecialchars($_SERVER['REMOTE_ADDR']); ?></div>

                                <div class="info-label">User Agent:</div>
                                <div class="info-value"><?php echo htmlspecialchars($_SERVER['HTTP_USER_AGENT'] ?? 'N/A'); ?></div>

                                <div class="info-label">Server Software:</div>
                                <div class="info-value"><?php echo htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? 'N/A'); ?></div>
                            </div>
                        </div>

                        <div class="page-info-box">
                            <h4>👤 Session Information</h4>
                            <div class="info-grid">
                                <div class="info-label">Logged in as:</div>
                                <div class="info-value"><?php echo htmlspecialchars($_SESSION['username']); ?></div>

                                <div class="info-label">Login Time:</div>
                                <div class="info-value"><?php echo htmlspecialchars($_SESSION['login_time']); ?></div>

                                <div class="info-label">Session ID:</div>
                                <div class="info-value"><?php echo htmlspecialchars(session_id()); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <script src="FI.js"></script>

</body>

</html>